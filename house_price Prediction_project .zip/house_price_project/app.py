from flask import Flask, render_template, request
import joblib

app = Flask(__name__)
model = joblib.load('house_model.pkl')
features = joblib.load('features.pkl')

@app.route('/')
def home():
    return render_template('index.html', features=features)

@app.route('/predict', methods=['POST'])
def predict():
    input_data = [float(request.form.get(f)) for f in features]
    prediction = model.predict([input_data])[0]
    return render_template('index.html', prediction=round(prediction, 2), features=features)

if __name__ == '__main__':
    app.run(debug=True)
